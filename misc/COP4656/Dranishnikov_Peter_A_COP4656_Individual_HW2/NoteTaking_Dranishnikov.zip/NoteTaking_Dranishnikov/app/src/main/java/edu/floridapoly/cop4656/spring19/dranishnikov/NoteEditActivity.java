package edu.floridapoly.cop4656.spring19.dranishnikov;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class NoteEditActivity extends AppCompatActivity
{
    private Note mNote;
    private static final String EXTRA_NOTE_ENTRY = "note_entry";
    //private static final String EXTRA_NOTE_NAME = "note_name";
    private Button mUpdateButton;
    private Button mDeleteButton;
    private Button mCancelButton;
    private EditText mNoteInputText;
    private TextView mDateTimeText;

    public static Intent newIntent(Context packageContext, Note note)
    {
        Intent i = new Intent(packageContext, NoteEditActivity.class);
        i.putExtra(EXTRA_NOTE_ENTRY, note);
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        //Note mNote = (Note) savedInstanceState.getSerializable("note_entry");
        mNote = (Note) getIntent().getSerializableExtra(EXTRA_NOTE_ENTRY);
        setContentView(R.layout.activity_note_edit);

        mNoteInputText = findViewById(R.id.note_text_editor);
        mDeleteButton = findViewById(R.id.delete_button);
        mUpdateButton = findViewById(R.id.update_button);
        mCancelButton = findViewById(R.id.cancel_button_edit);
        mDateTimeText = findViewById(R.id.datetime_view_edit);

        getSupportActionBar().setTitle("Edit Note");

        mNoteInputText.setText(mNote.getNoteText());
        mDateTimeText.setText(mNote.getTimestamp());

        mCancelButton.setOnClickListener(v -> finish());
        mDeleteButton.setOnClickListener(v -> {
            //do delete flag
            Intent dat = new Intent();
            mNote.setDeleteFlag(true);
            dat.putExtra(EXTRA_NOTE_ENTRY, mNote);
            setResult(RESULT_OK, dat);
            finish();
        });
        mUpdateButton.setOnClickListener(v -> {
            Intent data = new Intent();
            String note_text = mNoteInputText.getText().toString();

            if(note_text.isEmpty())
            {
                Toast.makeText(NoteEditActivity.this, "Nothing entered Yet", Toast.LENGTH_SHORT).show();
            }
            else
            {
                mNote.setNoteText(note_text);
                data.putExtra(EXTRA_NOTE_ENTRY, mNote);
                setResult(RESULT_OK, data);
                finish();
            }
        });
    }
}
