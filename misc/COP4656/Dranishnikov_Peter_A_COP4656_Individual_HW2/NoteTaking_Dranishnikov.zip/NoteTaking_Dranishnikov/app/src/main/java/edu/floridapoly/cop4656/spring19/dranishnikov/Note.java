package edu.floridapoly.cop4656.spring19.dranishnikov;

import java.io.Serializable;

public class Note implements Serializable
{
    private long mNoteID = 0;
    private int localID = 0;
    private String mNoteText;
    private String mFullName;
    private String mTimestamp;
    private boolean mDeleteFlag = false;

    public boolean isDeleteFlag()
    {
        return mDeleteFlag;
    }

    public void setDeleteFlag(boolean mDeleteFlag)
    {
        this.mDeleteFlag = mDeleteFlag;
    }

    public Note()
    {
        this.mFullName = "";
        this.mNoteText = "";
        this.mTimestamp = null;
    }

    public Note(String mNoteText, String mTimestamp)
    {
        this.mNoteText = mNoteText;
        this.mTimestamp = mTimestamp;
        this.mFullName = "";
        this.mNoteID = 0;
        this.mDeleteFlag = false;
    }

    public Note(String noteText, String fullName, String timestamp)
    {
        this.mNoteText = noteText;
        this.mFullName = fullName;
        this.mTimestamp = timestamp;
    }

    public Note(int mNoteID, String mNoteText, String mFullName, String mTimestamp)
    {
        this.mNoteID = (long)mNoteID;
        this.mNoteText = mNoteText;
        this.mFullName = mFullName;
        this.mTimestamp = mTimestamp;
    }

    public Note(long mNoteID, String mNoteText, String mFullName, String mTimestamp)
    {
        this.mNoteID = mNoteID;
        this.mNoteText = mNoteText;
        this.mFullName = mFullName;
        this.mTimestamp = mTimestamp;
    }

    public Note(long mNoteID, String mNoteText, String mFullName, String mTimestamp, boolean mDeleteFlag)
    {
        this.mNoteID = mNoteID;
        this.mNoteText = mNoteText;
        this.mFullName = mFullName;
        this.mTimestamp = mTimestamp;
        this.mDeleteFlag = mDeleteFlag;
    }

    public String getNoteText()
    {
        return mNoteText;
    }

    public void setNoteText(String mNoteText)
    {
        this.mNoteText = mNoteText;
    }

    public String getFullName()
    {
        return mFullName;
    }

    public void setFullName(String mFullName)
    {
        this.mFullName = mFullName;
    }

    public String getTimestamp()
    {
        return mTimestamp;
    }

    public void setTimestamp(String timestamp)
    {
        this.mTimestamp = timestamp;
    }

    /*public long getNoteID()
    {
        return mNoteID;
    }*/
    public int getNoteID(){return (int)mNoteID;}

    public void setNoteID(int mNoteID)
    {
        this.mNoteID = (long)mNoteID;
    }
    public void setNoteID(long mNoteID) { this.mNoteID = mNoteID;}

    public int getLocalID()
    {
        return localID;
    }

    public void setLocalID(int localID)
    {
        this.localID = localID;
    }

}