package edu.floridapoly.cop4656.spring19.dranishnikov;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<NoteHolder>
{
    private List<Note> mNotes;
    public NoteAdapter(List<Note> notes)
    {
        mNotes = notes;
    }

    @Override
    public NoteHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_note, parent, false);
        return new NoteHolder(itemView);
    }

    @Override
    public void onBindViewHolder(NoteHolder holder, int position)
    {
        Note note = mNotes.get(position);
        holder.bind(note);
    }

    @Override
    public int getItemCount()
    {
        return mNotes.size();
    }
}