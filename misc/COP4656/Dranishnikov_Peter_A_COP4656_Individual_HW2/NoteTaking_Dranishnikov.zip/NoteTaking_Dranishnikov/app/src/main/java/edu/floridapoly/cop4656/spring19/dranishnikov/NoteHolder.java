package edu.floridapoly.cop4656.spring19.dranishnikov;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

public class NoteHolder extends RecyclerView.ViewHolder implements View.OnClickListener
{
    private Note mNote;
    private TextView mNoteTextView;
    private TextView mDateTextView;
    //TODO add additional fields as necessary

    public NoteHolder(View view)
    {
        super(view);
        //TODO cardview?
        itemView.setOnClickListener(this);
        mNoteTextView = itemView.findViewById(R.id.note_text);
        mDateTextView = itemView.findViewById(R.id.date_time);
    }

    public void bind(Note note)
    {
        mNote = note;
        mNoteTextView.setText(mNote.getNoteText());
        mDateTextView.setText(mNote.getTimestamp().toString());
    }

    @Override
    public void onClick(View view)
    {
        //do nothing, handled by recyclerview
    }
}