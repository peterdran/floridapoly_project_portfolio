package edu.floridapoly.cop4656.spring19.dranishnikov;

import android.content.Context;

import java.util.List;

public class NoteDeck
{
    private static NoteDeck sNoteDeck;
    private List<Note> mNotes;

    private NoteDeck(Context context)
    {
        //from SQLite db
    }

    public static NoteDeck get(Context context)
    {
        if(sNoteDeck == null)
        {
            sNoteDeck = new NoteDeck(context);
        }
        return sNoteDeck;
    }

    public List<Note> getNotes()
    {
        return mNotes;
    }

    public Note getNote() //TODO UUID or other ID system
    {
        //TODO construct proper query
        return null;
    }
}
