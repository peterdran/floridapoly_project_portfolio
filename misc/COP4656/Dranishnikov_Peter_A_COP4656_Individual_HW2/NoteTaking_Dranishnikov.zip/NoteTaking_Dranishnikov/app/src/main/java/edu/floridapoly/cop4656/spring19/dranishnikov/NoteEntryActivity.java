package edu.floridapoly.cop4656.spring19.dranishnikov;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Date;

public class NoteEntryActivity extends AppCompatActivity
{
    private Note mNote;
    public static final String EXTRA_NOTE_ENTRY = "note_entry";
    private static final String EXTRA_NOTE_NAME = "note_name";
    private Button mSaveButton;
    private Button mCancelButton;
    private EditText mNoteInputText;
    private TextView mDateTimeText;

    public static Intent newIntent(Context packageContext)
    {
        Intent intent = new Intent(packageContext, NoteEntryActivity.class);

        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        String now = (new Date()).toString();
        setContentView(R.layout.activity_note_entry);

        mNoteInputText = findViewById(R.id.note_text_entry); //IDE said casting was redundant
        mCancelButton = findViewById(R.id.cancel_button);
        mSaveButton = findViewById(R.id.save_button);
        mDateTimeText = findViewById(R.id.datetime_view_create);
        mDateTimeText.setText(now);

        getSupportActionBar().setTitle("New Note");

        mCancelButton.setOnClickListener(v -> finish());
        mSaveButton.setOnClickListener(v -> {
            Intent data = new Intent();
            String note_text = mNoteInputText.getText().toString();
            Note note = new Note(note_text, now);

            if(note_text.isEmpty())
            {
                Toast.makeText(NoteEntryActivity.this, "Nothing entered Yet", Toast.LENGTH_SHORT).show();
            }
            else
            {
                data.putExtra(EXTRA_NOTE_ENTRY, note);
                setResult(RESULT_OK, data);
                finish();
            }
        });
    }
}
