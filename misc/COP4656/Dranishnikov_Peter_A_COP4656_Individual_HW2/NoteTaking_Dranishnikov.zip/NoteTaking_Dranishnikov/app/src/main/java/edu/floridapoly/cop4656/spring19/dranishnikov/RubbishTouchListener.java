package edu.floridapoly.cop4656.spring19.dranishnikov;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

public class RubbishTouchListener implements RecyclerView.OnItemTouchListener
{
    private ClickListener clicklistener;
    private GestureDetector gestureDetector;

    public RubbishTouchListener(Context context, final RecyclerView recycleView, final ClickListener clicklistener)
    {

        this.clicklistener = clicklistener;
        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onSingleTapUp(MotionEvent event)
            {
                return true; //hold on
            }

            @Override
            public void onLongPress(MotionEvent event)
            {
                /*View child = recycleView.findChildViewUnder(event.getX(), event.getY());
                if (child != null && clicklistener != null)
                {
                    clicklistener.onLongClick(child, recycleView.getChildAdapterPosition(child));
                }*/
            }
        });
    }

    @Override
    public boolean onInterceptTouchEvent(RecyclerView recycler, MotionEvent event)
    {
        View child = recycler.findChildViewUnder(event.getX(), event.getY());
        if (child != null && clicklistener != null && gestureDetector.onTouchEvent(event))
        {
            clicklistener.onClick(child, recycler.getChildAdapterPosition(child));
        }
        //TODO do something else?
        return false;
    }

    @Override
    public void onTouchEvent(RecyclerView recycler, MotionEvent event)
    {
        //TODO do something?
    }

    @Override
    public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) 
    {
        //TODO do nothing?
    }

    public interface ClickListener 
    {
        void onClick(View view, int position);
        void onLongClick(View view, int position);
    }
}
