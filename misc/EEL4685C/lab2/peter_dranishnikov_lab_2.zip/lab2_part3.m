%Peter A. Dranishnikov
%Lab 2
%EEL4685C
%Tuesday, January 29th, 2019 23:59
%part 3
%adapted from "circle_demo.m" by Dr. Foster @ FPU

filename = input("Please enter a filename: ", 's');
file_params = fopen(filename, 'r');
dim = fscanf(file_params, "Dim: %d"); % height and width of image in pixels (square image)
red_radius = fscanf(file_params, "\nRed Radius %d\n");
green_radius = fscanf(file_params, "\nGreen Radius %d\n");
blue_radius = fscanf(file_params, "\nBlue Radius %d");
fclose(file_params);

red_center = input("Please enter red circle location [x,y]: ");
green_center = input("Please enter green circle location [x,y]: ");
blue_center = input("Please enter blue circle location [x,y]: ");
pic = uint8(zeros(dim,dim,3)); % black image gen

file_writeout = fopen('counts.txt', 'w');
[pic, pix_count] = circle_create(pic, "red", red_radius, red_center);
fprintf(file_writeout,"The red circle at (%d,%d) contains %d pixels.\n",red_center(1), red_center(2), pix_count);
[pic, pix_count] = circle_create(pic, "green", green_radius, green_center);
fprintf(file_writeout,"The green circle at (%d,%d) contains %d pixels.\n",green_center(1), green_center(2), pix_count);
[pic, pix_count] = circle_create(pic, "blue", blue_radius, blue_center);
fprintf(file_writeout,"The blue circle at (%d,%d) contains %d pixels.\n",blue_center(1), blue_center(2), pix_count);
fclose(file_writeout);
image(pic);axis square;

function [r_pic, num_pixels] = circle_create(i_pic, color, radius, coords)
% circle_create: creates a shaded circle
% from radius (natural scalar), and center at coords(x,y)
% with color (string) color
% on picture i_pic
% returns: r_pic
    
    num_pixels = 0;
    color = lower(color);
    switch color
        case "red"
            color = 1;
        case "green"
            color = 2;
        case "blue"
            color = 3;
    end
    
    % each color channel ranges from 0-255. 
    % Use constants below to affect circle's appearance
    COLORMAX = 255; %  choose from REDMIN < REDMAX <=255 
    COLORMIN = 0; % choose from 0 <= REDMIN < REDMAX
    COLORRANGE = COLORMAX-COLORMIN+1; % Don't change this
    
    for x = 1:1:size(i_pic,2) % for every row in the image...
        for y = 1:1:size(i_pic,1) % for every pixel in a row...
            dist_from_center =sqrt((coords(1)-x)^2 + (coords(2)-y)^2);
            if dist_from_center < radius %point lies within circle
                num_pixels = num_pixels + 1; %matlab's behind the times
                normalized_img = (radius^2 - dist_from_center^2)/radius^2;
                scaled_img = normalized_img*COLORRANGE+COLORMIN; % scale to desired range
                i_pic(y,x,color) = uint8(scaled_img); % pay attention to order!!!  
            end
        end
    end
    r_pic = i_pic;

end